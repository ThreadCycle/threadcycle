-- ThreadCycle initial schema. Run in Supabase SQL Editor.
-- Enable RLS and use these policies before exposing the project publicly.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  bio text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  story text,
  category text not null check (category in ('Tops','Outerwear','Bottoms','Shoes','Accessories')),
  size text,
  condition text not null default 'Good' check (condition in ('New with tags','Like new','Very good','Good','Fair')),
  price_cents integer not null check (price_cents > 0),
  currency text not null default 'USD',
  image_url text,
  city text,
  status text not null default 'active' check (status in ('draft','active','reserved','sold','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, listing_id)
);

create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'requested' check (status in ('requested','accepted','declined','cancelled','expired','converted')),
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  unique(listing_id,buyer_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(listing_id,buyer_id,seller_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists listings_status_created_idx on public.listings(status,created_at desc);
create index if not exists listings_seller_idx on public.listings(seller_id);
create index if not exists reservations_buyer_idx on public.reservations(buyer_id);
create index if not exists messages_conversation_idx on public.messages(conversation_id,created_at);

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.favorites enable row level security;
alter table public.reservations enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create policy "Profiles are publicly readable" on public.profiles for select using (true);
create policy "Users create their own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Users update their own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "Active listings are publicly readable" on public.listings for select using (status = 'active' or auth.uid() = seller_id);
create policy "Sellers create their own listings" on public.listings for insert with check (auth.uid() = seller_id);
create policy "Sellers update their own listings" on public.listings for update using (auth.uid() = seller_id) with check (auth.uid() = seller_id);
create policy "Sellers delete their own listings" on public.listings for delete using (auth.uid() = seller_id);

create policy "Users manage their own favorites" on public.favorites for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Buyers see their reservations" on public.reservations for select using (auth.uid() = buyer_id or exists (select 1 from public.listings l where l.id = listing_id and l.seller_id = auth.uid()));
create policy "Buyers create their reservations" on public.reservations for insert with check (auth.uid() = buyer_id);
create policy "Participants update reservations" on public.reservations for update using (auth.uid() = buyer_id or exists (select 1 from public.listings l where l.id = listing_id and l.seller_id = auth.uid()));

create policy "Conversation participants can read" on public.conversations for select using (auth.uid() = buyer_id or auth.uid() = seller_id);
create policy "Buyers create conversations" on public.conversations for insert with check (auth.uid() = buyer_id);
create policy "Participants read messages" on public.messages for select using (exists (select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())));
create policy "Participants send messages" on public.messages for insert with check (auth.uid() = sender_id and exists (select 1 from public.conversations c where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())));

-- Create a profile row automatically when a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
