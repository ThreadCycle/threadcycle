# ThreadCycle MVP

A cross-platform Expo app for iOS, Android, and web, using Supabase for authentication and marketplace data.

## What is included

- Responsive Expo / React Native app shell
- ThreadCycle branding and marketplace browse experience
- Demo clothing inventory for preview only
- Search and category filters
- Favorites (local for demo inventory; database-backed for real listings)
- Email/password sign-in and registration
- Seller listing form backed by Supabase
- Reservation request records (no payment is collected)
- Supabase SQL schema for profiles, listings, favorites, reservations, conversations, and messages
- Row-level security policies

## Important current limitations

This is a starter MVP, not a production marketplace. Demo inventory is sample data and cannot be purchased. The first pass does not yet include image uploads, production real-time chat, seller payouts, Stripe checkout, shipping labels, dispute handling, moderation dashboard, push notifications, or app-store publishing. Do not accept payments or launch public transactions until these are implemented and tested.

## Run locally

1. Install Node.js LTS.
2. Extract this project.
3. In this folder, run:

   ```bash
   npm install
   npx expo start
   ```

4. Press `w` for the web preview, or scan the QR code with Expo Go on your phone.

## Connect the live backend

1. Create a project at https://supabase.com.
2. In Supabase, open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy the Project URL and anon/public key.
4. Copy `.env.example` to `.env` and fill in:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```

5. Restart Expo after editing `.env`.

The anon key is intended for client use when Row Level Security is correctly configured. Never put a Supabase service-role key or Stripe secret key in the app.

## Recommended next production milestones

1. Add profile editing and profile photos.
2. Add secure image uploads using a Supabase Storage bucket and file-size/type validation.
3. Complete conversation creation and real-time message subscriptions.
4. Add reservation acceptance/expiry and prevent two buyers reserving the same item.
5. Add Stripe Connect with server-side payment intents, webhook verification, seller onboarding, refunds, and payout handling.
6. Add shipping address handling, order status, returns/refunds, reporting, moderation, and audit logs.
7. Add tests, privacy policy, terms, community guidelines, and support contact.
8. Test on real iOS and Android devices; then configure Apple and Google developer accounts and submit for review.

## Brand

- Name: ThreadCycle
- Tagline: BUY & SELL SECONDHAND CLOTHING
- Primary forest green: `#244B3C`
- Warm cream: `#F5F0E8`
- Rust accent: `#A85C42`

## Cost notes

The starter source is free. Supabase, Expo, hosting, domains, payment processing, and app-store accounts may have usage fees or paid requirements. Check current pricing before enabling paid services.
