import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView,
  Platform, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text,
  TextInput, TouchableOpacity, View
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import { supabase, supabaseReady } from "./lib/supabase";

const GREEN = "#244B3C", CREAM = "#F5F0E8", INK = "#242820", MUTED = "#77786F";
const CATEGORIES = ["All", "Tops", "Outerwear", "Bottoms", "Shoes", "Accessories"];
const DEMO = [
  {id:"demo-1", title:"Vintage denim jacket", category:"Outerwear", price:42, size:"M", condition:"Good", city:"Portland", image_url:"https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=800", story:"A favorite road-trip layer, ready for its next chapter.", seller_name:"Maya"},
  {id:"demo-2", title:"Classic white shirt", category:"Tops", price:24, size:"S", condition:"Very good", city:"London", image_url:"https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=800", story:"An easy everyday piece that deserves more wear.", seller_name:"Alex"},
  {id:"demo-3", title:"Everyday blue jeans", category:"Bottoms", price:30, size:"28", condition:"Good", city:"Toronto", image_url:"https://images.unsplash.com/photo-1542272604-787c3835535d?w=800", story:"Broken-in denim with plenty of life left.", seller_name:"Jordan"},
  {id:"demo-4", title:"Leather shoulder bag", category:"Accessories", price:38, size:"One size", condition:"Very good", city:"Paris", image_url:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800", story:"A small everyday bag with a lot of character.", seller_name:"Camille"},
  {id:"demo-5", title:"Retro sneakers", category:"Shoes", price:46, size:"8", condition:"Good", city:"Austin", image_url:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800", story:"Still plenty of miles left in these.", seller_name:"Taylor"},
  {id:"demo-6", title:"Cozy knit sweater", category:"Tops", price:34, size:"M", condition:"Very good", city:"Melbourne", image_url:"https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800", story:"A soft layer for cooler days.", seller_name:"Riley"}
];

function Button({title, onPress, outline=false, disabled=false}) {
  return <TouchableOpacity disabled={disabled} onPress={onPress} style={[styles.button, outline && styles.outline, disabled && {opacity:.45}]}>
    <Text style={[styles.buttonText, outline && {color:GREEN}]}>{title}</Text>
  </TouchableOpacity>;
}
function Field({label, value, onChangeText, placeholder, keyboardType, multiline=false, secureTextEntry=false}) {
  return <View style={{marginBottom:12}}>
    <Text style={styles.label}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#999" keyboardType={keyboardType} multiline={multiline} secureTextEntry={secureTextEntry} style={[styles.input, multiline && {height:86,textAlignVertical:"top"}]} />
  </View>;
}

export default function App() {
  const [session,setSession] = useState(null);
  const [loading,setLoading] = useState(true);
  const [tab,setTab] = useState("Discover");
  const [items,setItems] = useState(DEMO);
  const [saved,setSaved] = useState([]);
  const [reservations,setReservations] = useState([]);
  const [category,setCategory] = useState("All");
  const [search,setSearch] = useState("");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [authMode,setAuthMode] = useState("signin");
  const [draft,setDraft] = useState({title:"",price:"",category:"Tops",size:"",condition:"Good",image_url:"",story:""});
  const [messages,setMessages] = useState([]);
  const [messageText,setMessageText] = useState("");
  const [activeListing,setActiveListing] = useState(null);

  useEffect(() => {
    let mounted = true;
    async function init() {
      if (supabaseReady) {
        const {data:{session: current}} = await supabase.auth.getSession();
        if (mounted) setSession(current);
        const {data:listener} = supabase.auth.onAuthStateChange((_event,next)=>setSession(next));
        if (mounted) setLoading(false);
        return () => listener.subscription.unsubscribe();
      }
      if (mounted) setLoading(false);
    }
    const cleanup = init();
    return () => { mounted=false; Promise.resolve(cleanup).then(fn=>fn && fn()); };
  }, []);

  const user = session?.user;
  useEffect(() => { if(user) loadData(); }, [user?.id]);

  async function loadData() {
    if (!supabaseReady || !user) return;
    const [{data: listings},{data: likes},{data: holds}] = await Promise.all([
      supabase.from("listings").select("*, profiles(display_name)").eq("status","active").order("created_at",{ascending:false}),
      supabase.from("favorites").select("listing_id").eq("user_id",user.id),
      supabase.from("reservations").select("listing_id,status").eq("buyer_id",user.id)
    ]);
    if (listings?.length) setItems(listings.map(x=>({...x,seller_name:x.profiles?.display_name || "ThreadCycle member"})));
    setSaved(likes?.map(x=>x.listing_id) || []);
    setReservations(holds?.filter(x=>x.status!=="cancelled").map(x=>x.listing_id) || []);
  }

  const filtered = useMemo(()=>items.filter(x=>(category==="All"||x.category===category)&&(`${x.title} ${x.category} ${x.city||""}`).toLowerCase().includes(search.toLowerCase())),[items,category,search]);

  async function authenticate() {
    if (!email.trim() || !password) return Alert.alert("Add your details","Enter an email and password.");
    if (!supabaseReady) return Alert.alert("Backend not connected","Add your Supabase project URL and anon key to .env before using accounts.");
    const fn = authMode==="signup" ? supabase.auth.signUp({email:email.trim(),password}) : supabase.auth.signInWithPassword({email:email.trim(),password});
    const {error} = await fn;
    if(error) Alert.alert("Account error",error.message);
  }
  async function signOut(){ if(supabaseReady) await supabase.auth.signOut(); setSession(null); }

  async function toggleSave(item) {
    if(String(item.id).startsWith("demo-")) {
      setSaved(old=>old.includes(item.id)?old.filter(x=>x!==item.id):[...old,item.id]); return;
    }
    if(!user) return Alert.alert("Sign in required","Create an account to save pieces.");
    const exists=saved.includes(item.id);
    const result=exists
      ? await supabase.from("favorites").delete().eq("user_id",user.id).eq("listing_id",item.id)
      : await supabase.from("favorites").insert({user_id:user.id,listing_id:item.id});
    if(result.error) Alert.alert("Couldn't update saved pieces",result.error.message);
    else setSaved(old=>exists?old.filter(x=>x!==item.id):[...old,item.id]);
  }

  async function createListing() {
    if(!user) return Alert.alert("Sign in required","Create an account before listing clothing.");
    if(!draft.title.trim()||!draft.price||Number(draft.price)<=0) return Alert.alert("Missing details","Add an item name and a valid price.");
    const {data:profile} = await supabase.from("profiles").select("display_name").eq("id",user.id).maybeSingle();
    const {data,error} = await supabase.from("listings").insert({
      seller_id:user.id,title:draft.title.trim(),price_cents:Math.round(Number(draft.price)*100),
      category:draft.category,size:draft.size,condition:draft.condition,image_url:draft.image_url||null,
      story:draft.story,city:null,status:"active"
    }).select().single();
    if(error) return Alert.alert("Listing failed",error.message);
    setItems(old=>[{...data,seller_name:profile?.display_name||user.email},...old]);
    setDraft({title:"",price:"",category:"Tops",size:"",condition:"Good",image_url:"",story:""});
    setTab("Discover"); Alert.alert("Listed","Your item is now in the ThreadCycle marketplace.");
  }

  async function reserve(item) {
    if(String(item.id).startsWith("demo-")) return Alert.alert("Demo item","Sample items are for preview only. Connect Supabase and list real items to test reservations.");
    if(!user) return Alert.alert("Sign in required","Create an account to reserve a piece.");
    if(item.seller_id===user.id) return Alert.alert("Your listing","You can't reserve your own listing.");
    const {error} = await supabase.from("reservations").insert({listing_id:item.id,buyer_id:user.id,status:"requested"});
    if(error) return Alert.alert("Reservation failed",error.message);
    setReservations(old=>[...old,item.id]); setActiveListing(item); setTab("Messages");
    Alert.alert("Request sent","Your reservation request was sent. Payment is not collected in this MVP.");
  }

  async function sendMessage() {
    if(!user||!activeListing||!messageText.trim()) return;
    Alert.alert("Messaging setup","Conversation messaging tables are included in the database schema. This first build uses a local preview for the message composer; connect the conversation screen in the next development pass.");
    setMessages(old=>[...old,{id:Date.now(),body:messageText.trim(),mine:true}]); setMessageText("");
  }

  function renderCard({item}) {
    const price=(item.price_cents!=null?item.price_cents/100:item.price);
    const isSaved=saved.includes(item.id);
    return <View style={styles.card}>
      {item.image_url ? <Image source={{uri:item.image_url}} style={styles.photo} /> : <View style={[styles.photo,{alignItems:"center",justifyContent:"center"}]}><Text style={{fontSize:36}}>👕</Text></View>}
      <View style={{padding:11}}>
        <View style={{flexDirection:"row",justifyContent:"space-between",alignItems:"flex-start"}}>
          <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
          <TouchableOpacity onPress={()=>toggleSave(item)}><Text style={{fontSize:23,color:GREEN}}>{isSaved?"♥":"♡"}</Text></TouchableOpacity>
        </View>
        <Text style={styles.price}>${Number(price).toFixed(2)}</Text>
        <Text style={styles.meta}>{item.size ? `Size ${item.size} · `:""}{item.condition||"Pre-loved"} · {item.city||"Worldwide"}</Text>
        <Text style={styles.meta}>From {item.seller_name||"a ThreadCycle closet"}</Text>
        <Button title="Reserve piece" onPress={()=>reserve(item)} />
      </View>
    </View>;
  }

  if(loading) return <SafeAreaView style={styles.center}><ActivityIndicator color={GREEN}/></SafeAreaView>;

  return <SafeAreaView style={styles.safe}>
    <ExpoStatusBar style="dark"/>
    <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==="ios"?"padding":undefined}>
      <View style={styles.header}>
        <View><Text style={styles.logo}>ThreadCycle<Text style={{color:"#A85C42"}}> ↻</Text></Text><Text style={styles.tagline}>BUY & SELL SECONDHAND CLOTHING</Text></View>
        <Text style={styles.globe}>🌎</Text>
      </View>
      {!supabaseReady && <View style={styles.notice}><Text style={styles.noticeText}>Preview mode · Connect Supabase to enable real accounts and listings</Text></View>}
      {!user && tab==="Profile" ? <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>{authMode==="signup"?"Join ThreadCycle":"Welcome back"}</Text>
        <Field label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address"/>
        <Field label="Password" value={password} onChangeText={setPassword} placeholder="At least 8 characters" secureTextEntry/>
        <Button title={authMode==="signup"?"Create account":"Sign in"} onPress={authenticate}/>
        <TouchableOpacity onPress={()=>setAuthMode(authMode==="signup"?"signin":"signup")}><Text style={styles.switch}>{authMode==="signup"?"Already have an account? Sign in":"New here? Create an account"}</Text></TouchableOpacity>
      </ScrollView> : tab==="Discover" ? <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}><Text style={styles.eyebrow}>CLOTHES HAVE STORIES</Text><Text style={styles.heroTitle}>Find your next favorite.</Text><Text style={styles.heroSub}>Browse pieces from closets around the world.</Text></View>
        <TextInput value={search} onChangeText={setSearch} placeholder="Search jackets, jeans, vintage..." style={styles.search}/>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginVertical:14}}>
          {CATEGORIES.map(c=><TouchableOpacity key={c} onPress={()=>setCategory(c)} style={[styles.chip,category===c&&styles.chipActive]}><Text style={[styles.chipText,category===c&&{color:"white"}]}>{c}</Text></TouchableOpacity>)}
        </ScrollView>
        <Text style={styles.sectionTitle}>Discover pieces</Text>
        <FlatList data={filtered} renderItem={renderCard} keyExtractor={x=>String(x.id)} numColumns={2} scrollEnabled={false} columnWrapperStyle={{gap:12}} contentContainerStyle={{gap:12}} ListEmptyComponent={<Text style={styles.meta}>No pieces found. Try another search.</Text>}/>
      </ScrollView> : tab==="Saved" ? <ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>Your saved pieces</Text><FlatList data={items.filter(x=>saved.includes(x.id))} renderItem={renderCard} keyExtractor={x=>String(x.id)} numColumns={2} scrollEnabled={false} columnWrapperStyle={{gap:12}} contentContainerStyle={{gap:12}}/></ScrollView>
      : tab==="Sell" ? <ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>List a piece</Text><Text style={styles.subtitle}>Give something in your closet a new story.</Text>
        <Field label="Item name" value={draft.title} onChangeText={v=>setDraft({...draft,title:v})} placeholder="Vintage denim jacket"/>
        <Field label="Price (USD)" value={draft.price} onChangeText={v=>setDraft({...draft,price:v})} placeholder="35.00" keyboardType="decimal-pad"/>
        <Text style={styles.label}>Category</Text><View style={styles.wrap}>{CATEGORIES.filter(x=>x!=="All").map(c=><TouchableOpacity key={c} style={[styles.chip,draft.category===c&&styles.chipActive]} onPress={()=>setDraft({...draft,category:c})}><Text style={[styles.chipText,draft.category===c&&{color:"white"}]}>{c}</Text></TouchableOpacity>)}</View>
        <Field label="Size" value={draft.size} onChangeText={v=>setDraft({...draft,size:v})} placeholder="M, 8, One size"/>
        <Field label="Photo URL" value={draft.image_url} onChangeText={v=>setDraft({...draft,image_url:v})} placeholder="https://..."/>
        <Field label="Story behind the piece" value={draft.story} onChangeText={v=>setDraft({...draft,story:v})} placeholder="Tell its next owner something about this piece..." multiline/>
        <Button title="Publish listing" onPress={createListing}/>
        {!user&&<Text style={styles.meta}>Sign in from Profile before publishing.</Text>}
      </ScrollView>
      : tab==="Messages" ? <ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>Messages</Text><Text style={styles.subtitle}>Connect with the person behind the piece.</Text>
        {activeListing ? <View style={styles.panel}><Text style={styles.cardTitle}>{activeListing.title}</Text><Text style={styles.meta}>Reservation request started</Text><Field label="Message" value={messageText} onChangeText={setMessageText} placeholder="Hi! I'd love to know more about this piece." multiline/><Button title="Send message (preview)" onPress={sendMessage}/>{messages.map(m=><Text key={m.id} style={styles.message}>{m.body}</Text>)}</View> : <View style={styles.panel}><Text style={styles.cardTitle}>Your inbox is ready</Text><Text style={styles.meta}>Reserve a real listing to start a conversation. Full real-time chat is a next build milestone.</Text></View>}
      </ScrollView>
      : <ScrollView contentContainerStyle={styles.content}><Text style={styles.heading}>Your closet profile</Text>
        <View style={styles.panel}><Text style={{fontSize:34}}>👕</Text><Text style={styles.cardTitle}>{user?.email||"Welcome to ThreadCycle"}</Text><Text style={styles.meta}>Discover. Connect. Rewear.</Text></View>
        <View style={styles.stats}><View style={styles.stat}><Text style={styles.statNum}>{saved.length}</Text><Text style={styles.meta}>Saved</Text></View><View style={styles.stat}><Text style={styles.statNum}>{reservations.length}</Text><Text style={styles.meta}>Reservations</Text></View></View>
        {user ? <Button title="Sign out" outline onPress={signOut}/> : <><Button title="Create account / Sign in" onPress={()=>setAuthMode("signup")}/><Text style={styles.meta}>Create an account to publish real listings and save items.</Text></>}
      </ScrollView>}
      <View style={styles.nav}>{["Discover","Saved","Sell","Messages","Profile"].map((t,i)=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={styles.navItem}><Text style={[styles.navIcon,tab===t&&{color:GREEN}]}>{["⌂","♡","＋","▤","◉"][i]}</Text><Text style={[styles.navLabel,tab===t&&{color:GREEN,fontWeight:"700"}]}>{t}</Text></TouchableOpacity>)}</View>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:CREAM},center:{flex:1,alignItems:"center",justifyContent:"center",backgroundColor:CREAM},
 header:{paddingHorizontal:18,paddingTop:10,paddingBottom:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
 logo:{fontSize:25,fontWeight:"900",letterSpacing:-1,color:GREEN},tagline:{fontSize:9,letterSpacing:1.7,color:MUTED,marginTop:2},globe:{fontSize:23},
 notice:{backgroundColor:"#E7E0D3",padding:8,alignItems:"center"},noticeText:{fontSize:11,color:"#665E50"},
 content:{padding:16,paddingBottom:28},hero:{backgroundColor:GREEN,borderRadius:18,padding:20,marginBottom:16},
 eyebrow:{fontSize:10,letterSpacing:2,color:"#D6DFD5"},heroTitle:{fontSize:26,fontWeight:"800",color:"white",marginTop:9},heroSub:{fontSize:13,color:"#E4E9E3",marginTop:6},
 search:{backgroundColor:"white",borderWidth:1,borderColor:"#E2DED5",borderRadius:12,padding:13,fontSize:14},
 chip:{borderWidth:1,borderColor:"#D8D2C7",borderRadius:20,paddingHorizontal:13,paddingVertical:8,marginRight:7,marginBottom:7},chipActive:{backgroundColor:GREEN,borderColor:GREEN},chipText:{fontSize:12,color:INK},
 sectionTitle:{fontSize:19,fontWeight:"800",color:INK,marginBottom:12},heading:{fontSize:25,fontWeight:"800",color:INK,marginBottom:8},subtitle:{fontSize:14,color:MUTED,marginBottom:20},
 card:{flex:1,minWidth:0,backgroundColor:"white",borderRadius:15,overflow:"hidden",borderWidth:1,borderColor:"#E8E3D9"},photo:{width:"100%",height:145,backgroundColor:"#E9E4DA"},cardTitle:{fontSize:13,fontWeight:"700",color:INK,flex:1},price:{fontSize:15,fontWeight:"800",color:GREEN,marginTop:4},meta:{fontSize:11,color:MUTED,marginTop:4,lineHeight:16},
 button:{backgroundColor:GREEN,paddingVertical:11,paddingHorizontal:14,borderRadius:10,alignItems:"center",marginTop:10},buttonText:{color:"white",fontSize:13,fontWeight:"700"},outline:{backgroundColor:"transparent",borderWidth:1,borderColor:GREEN},
 label:{fontSize:12,fontWeight:"700",color:INK,marginBottom:6},input:{backgroundColor:"white",borderWidth:1,borderColor:"#DED8CE",borderRadius:10,padding:12,fontSize:14,color:INK},
 switch:{textAlign:"center",color:GREEN,fontWeight:"700",marginTop:18},wrap:{flexDirection:"row",flexWrap:"wrap"},panel:{backgroundColor:"white",borderRadius:15,padding:16,borderWidth:1,borderColor:"#E8E3D9",marginVertical:10},
 stats:{flexDirection:"row",gap:12,marginVertical:12},stat:{flex:1,backgroundColor:"white",borderRadius:12,padding:16},statNum:{fontSize:24,fontWeight:"800",color:GREEN},message:{backgroundColor:"#E9EFE8",padding:10,borderRadius:10,marginTop:8,color:INK},
 nav:{flexDirection:"row",borderTopWidth:1,borderColor:"#E1DBD0",backgroundColor:"#FBF9F5",paddingTop:7,paddingBottom:Platform.OS==="ios"?12:7},
 navItem:{flex:1,alignItems:"center",gap:2},navIcon:{fontSize:19,color:"#8A897F"},navLabel:{fontSize:10,color:"#8A897F"}
});
